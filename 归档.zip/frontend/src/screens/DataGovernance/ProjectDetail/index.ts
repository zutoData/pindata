export { ProjectDetail } from './ProjectDetail';
export { RawDataTab } from './RawDataTab';
export { GovernedDataTab } from './GovernedDataTab';
export { KnowledgeTab } from './KnowledgeTab';
export { DatasetsTab } from './DatasetsTab';
export { AnalyticsTab } from './AnalyticsTab'; 